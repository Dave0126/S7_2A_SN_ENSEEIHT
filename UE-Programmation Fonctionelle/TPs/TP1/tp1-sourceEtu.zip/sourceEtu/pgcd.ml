(** Exercice à rendre **)
(** TO DO : contrat *)
let pgcd a b = failwith "TO DO"
(** TO DO : tests unitaires *)

